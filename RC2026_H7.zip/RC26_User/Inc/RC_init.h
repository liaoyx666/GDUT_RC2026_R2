#pragma once
#include "RC_task.h"
#include "RC_can.h"
#include "RC_tim.h"
#include "RC_m3508.h"
#include "RC_m2006.h"
#include "RC_m6020.h"
#include "RC_dm4310.h"
#include "RC_serial.h"
#include "RC_wave_generator.h"
#include "RC_timer.h"
#include "RC_flysky.h"
#include "RC_cdc.h"
#include "RC_omni_chassis.h"
#include "RC_go.h"
#include "RC_path.h"
#include "RC_best_path.h"
#include "RC_radar.h"
#include "RC_j60.h"
#include "RC_arm.h"
#include "RC_JY901S.h"
#include "RC_rs04.h"
#include "RC_vesc.h"
#include "RC_swerve_chassis.h"
#include "RC_chassis_jack.h"

#include "RC_arm_task.h"

#include "fdcan.h"
#include "tim.h"
#include "gpio.h"


#ifdef __cplusplus




#endif





#ifdef __cplusplus
extern "C" {
#endif


void All_Init();


	
#ifdef __cplusplus
}
#endif