#pragma once
#include <arm_math.h>



#ifdef __cplusplus
namespace chassis
{
	class WheelLeg
    {
    public:
		WheelLeg();
		virtual ~WheelLeg() {}
		
		
    protected:
		
    private:
    };
}
#endif
