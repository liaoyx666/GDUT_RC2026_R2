#pragma once
#include "RC_path.h"

#ifdef __cplusplus
namespace path
{
	class MF
    {
    public:
    
    protected:
    
    private:
    
    };
}
#endif
