function result = LQR_calc2(M,m,g,h,r,I)
    D = (M+m)*(m*h^2 + I) - m^2*h^2;
    A = [0 1 0 0; ((M+m)*m*g*h)/D 0 0 0;0 0 0 1;-(m^2*g*h^2)/D 0 0 0];
    B = [0; -(m*h)/(D*r);0;1/((M+m)*r)-(m^2*h^2)/((M+m)*D*r)];
    Q = diag([1 1 1 1]);%q q_d x x_d
    R = 33;
    result = lqr(A, B, Q, R);
end